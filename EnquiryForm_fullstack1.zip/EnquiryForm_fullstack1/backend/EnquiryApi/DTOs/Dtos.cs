using EnquiryApi.Models;

namespace EnquiryApi.DTOs;

// ---- Auth DTOs ----

public record RegisterDto(string Username, string Email, string Password);

public record LoginDto(string Username, string Password);

public record AuthResponseDto(string Token, string Username, string Role, DateTime ExpiresAt);

// ---- Enquiry DTOs ----
// We use separate DTOs (instead of exposing the EF entity directly) so the
// API contract is decoupled from the database schema and we control
// exactly what the client can send/receive.

public record EnquiryCreateDto(
    string FullName,
    string Email,
    string Phone,
    string Subject,
    string Message
);

public record EnquiryUpdateDto(
    string FullName,
    string Email,
    string Phone,
    string Subject,
    string Message,
    EnquiryStatus Status
);

public record EnquiryReadDto(
    int Id,
    string FullName,
    string Email,
    string Phone,
    string Subject,
    string Message,
    EnquiryStatus Status,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);
