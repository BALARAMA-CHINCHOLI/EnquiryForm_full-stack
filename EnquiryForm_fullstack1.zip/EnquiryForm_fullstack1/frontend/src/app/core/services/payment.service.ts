import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { loadStripe, Stripe, StripeElements } from '@stripe/stripe-js';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { PaymentIntentResponse } from '../models';

// Wraps Stripe.js (loaded via @stripe/stripe-js) plus the API call that
// creates the PaymentIntent server-side. The card number/CVC are entered
// into Stripe's hosted <PaymentElement>, never handled by our own code --
// this keeps the app out of PCI-DSS card-data scope.
@Injectable({ providedIn: 'root' })
export class PaymentService {
  private stripePromise: Promise<Stripe | null>;

  constructor(private http: HttpClient) {
    this.stripePromise = loadStripe(environment.stripePublishableKey);
  }

  async getStripe(): Promise<Stripe> {
    const stripe = await this.stripePromise;
    if (!stripe) throw new Error('Stripe.js failed to load.');
    return stripe;
  }

  createIntent(orderId: number) {
    return firstValueFrom(
      this.http.post<PaymentIntentResponse>(`${environment.apiUrl}/payments/intent`, { orderId })
    );
  }

  // Mounts Stripe's PaymentElement into the given DOM element id and
  // returns the Elements instance so the checkout component can call confirmPayment.
  async createElements(clientSecret: string, elementId: string): Promise<StripeElements> {
    const stripe = await this.getStripe();
    const elements = stripe.elements({ clientSecret });
    elements.create('payment').mount(`#${elementId}`);
    return elements;
  }

  async confirmPayment(elements: StripeElements, returnUrl: string) {
    const stripe = await this.getStripe();
    return stripe.confirmPayment({
      elements,
      confirmParams: { return_url: returnUrl },
      redirect: 'if_required'
    });
  }
}
