import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CartService } from '../../core/services/cart.service';
import { OrderService } from '../../core/services/order.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="min-h-screen bg-slate-50">
      <header class="bg-white border-b border-slate-200">
        <div class="max-w-3xl mx-auto px-4 sm:px-6 py-4">
          <h1 class="text-lg font-semibold text-slate-900">Your cart</h1>
        </div>
      </header>

      <main class="max-w-3xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        <div class="bg-white rounded-2xl shadow-sm border border-slate-200 divide-y divide-slate-100">
          @for (line of cart.lines(); track line.menuItem.id) {
            <div class="flex items-center justify-between gap-4 p-4">
              <div class="flex-1">
                <p class="font-medium text-slate-900">{{ line.menuItem.name }}</p>
                <p class="text-sm text-slate-500">{{ line.menuItem.price | currency }} each</p>
              </div>
              <div class="flex items-center gap-2">
                <button
                  (click)="cart.updateQuantity(line.menuItem.id, line.quantity - 1)"
                  class="w-7 h-7 rounded-full border border-slate-300 text-slate-600 hover:bg-slate-50"
                >−</button>
                <span class="w-6 text-center text-sm">{{ line.quantity }}</span>
                <button
                  (click)="cart.updateQuantity(line.menuItem.id, line.quantity + 1)"
                  class="w-7 h-7 rounded-full border border-slate-300 text-slate-600 hover:bg-slate-50"
                >+</button>
              </div>
              <p class="w-20 text-right font-medium text-slate-900">
                {{ line.menuItem.price * line.quantity | currency }}
              </p>
              <button (click)="cart.remove(line.menuItem.id)" class="text-sm text-red-600 hover:text-red-700">
                Remove
              </button>
            </div>
          } @empty {
            <p class="p-6 text-center text-sm text-slate-500">Your cart is empty.</p>
          }
        </div>

        @if (cart.lines().length > 0) {
          <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 space-y-4">
            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Delivery address</label>
              <textarea
                [(ngModel)]="deliveryAddress"
                rows="2"
                class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm
                       focus:outline-none focus:ring-2 focus:ring-brand-500"
              ></textarea>
            </div>

            <div class="flex items-center justify-between">
              <span class="text-slate-600">Total</span>
              <span class="text-xl font-semibold text-slate-900">{{ cart.total() | currency }}</span>
            </div>

            @if (errorMessage()) {
              <p class="text-sm text-red-600">{{ errorMessage() }}</p>
            }

            <button
              (click)="placeOrder()"
              [disabled]="!deliveryAddress.trim() || placing()"
              class="w-full rounded-lg bg-brand-600 text-white text-sm font-medium py-2.5
                     hover:bg-brand-700 transition disabled:opacity-50"
            >
              {{ placing() ? 'Placing order...' : 'Proceed to payment' }}
            </button>
          </div>
        }
      </main>
    </div>
  `
})
export class CartComponent {
  deliveryAddress = '';
  placing = signal(false);
  errorMessage = signal<string | null>(null);

  constructor(public cart: CartService, private orderService: OrderService, private router: Router) {}

  placeOrder(): void {
    this.placing.set(true);
    this.errorMessage.set(null);

    const payload = {
      items: this.cart.lines().map((l) => ({ menuItemId: l.menuItem.id, quantity: l.quantity })),
      deliveryAddress: this.deliveryAddress
    };

    this.orderService.create(payload).subscribe({
      next: (order) => {
        this.cart.clear();
        // Checkout page creates the Stripe PaymentIntent for this order id
        this.router.navigate(['/checkout', order.id]);
      },
      error: () => {
        this.errorMessage.set('Could not place order. Please try again.');
        this.placing.set(false);
      }
    });
  }
}
