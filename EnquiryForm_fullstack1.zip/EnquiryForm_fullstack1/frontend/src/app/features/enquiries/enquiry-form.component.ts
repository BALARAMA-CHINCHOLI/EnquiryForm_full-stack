import { Component, EventEmitter, Input, OnChanges, Output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { EnquiryService } from '../../core/services/enquiry.service';
import { Enquiry, EnquiryStatus } from '../../core/models';

// Single form reused for both "create" and "edit" -- when editingEnquiry
// is set, the form pre-fills and submit calls update() instead of create().
@Component({
  selector: 'app-enquiry-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
      <h2 class="font-medium text-slate-900 mb-4">
        {{ editingEnquiry ? 'Edit enquiry' : 'New enquiry' }}
      </h2>

      <form [formGroup]="form" (ngSubmit)="onSubmit()" class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <input formControlName="fullName" placeholder="Full name" [class]="inputClass" />
        <input formControlName="email" placeholder="Email" [class]="inputClass" />
        <input formControlName="phone" placeholder="Phone" [class]="inputClass" />
        <input formControlName="subject" placeholder="Subject" [class]="inputClass" />
        <textarea
          formControlName="message"
          placeholder="Message"
          rows="3"
          class="sm:col-span-2 rounded-lg border border-slate-300 px-3 py-2 text-sm
                 focus:outline-none focus:ring-2 focus:ring-brand-500"
        ></textarea>

        @if (editingEnquiry) {
          <select formControlName="status" [class]="inputClass">
            <option [value]="0">New</option>
            <option [value]="1">In Progress</option>
            <option [value]="2">Resolved</option>
          </select>
        }

        <div class="sm:col-span-2 flex gap-3">
          <button
            type="submit"
            [disabled]="form.invalid || saving()"
            class="rounded-lg bg-brand-600 text-white text-sm font-medium px-4 py-2
                   hover:bg-brand-700 transition disabled:opacity-50"
          >
            {{ saving() ? 'Saving...' : editingEnquiry ? 'Update' : 'Create' }}
          </button>

          @if (editingEnquiry) {
            <button
              type="button"
              (click)="cancelled.emit()"
              class="rounded-lg border border-slate-300 text-sm font-medium px-4 py-2 text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
          }
        </div>
      </form>
    </div>
  `
})
export class EnquiryFormComponent implements OnChanges {
  
  constructor(private fb: FormBuilder, private enquiryService: EnquiryService) {
    this.form = this.fb.group({
    fullName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    phone: [''],
    subject: ['', Validators.required],
    message: ['', Validators.required],
    status: [EnquiryStatus.New]
  });
  }
  
  @Input() editingEnquiry: Enquiry | null = null;
  @Output() saved = new EventEmitter<void>();
  @Output() cancelled = new EventEmitter<void>();


  form: any;

  saving = signal(false);

  readonly inputClass =
    'rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500';

  


  // Re-populate the form whenever a different enquiry is passed in for editing
  ngOnChanges(): void {
    if (this.editingEnquiry) {
      this.form.patchValue(this.editingEnquiry);
    } else {
      this.form.reset({ status: EnquiryStatus.New });
    }
  }

  onSubmit(): void {
    if (this.form.invalid) return;
    this.saving.set(true);
    const value = this.form.getRawValue();

    const request = this.editingEnquiry
      ? this.enquiryService.update(this.editingEnquiry.id, value as any)
      : this.enquiryService.create(value as any);

    request.subscribe({
      next: () => {
        this.saving.set(false);
        this.form.reset({ status: EnquiryStatus.New });
        this.saved.emit();
      },
      error: () => this.saving.set(false)
    });
  }
}
