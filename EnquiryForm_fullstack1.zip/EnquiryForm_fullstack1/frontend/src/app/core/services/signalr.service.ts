import { Injectable, signal } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { environment } from '../../../environments/environment';
import { AuthService } from './auth.service';
import { Enquiry } from '../models';

// Wraps the @microsoft/signalr client. Exposes the live enquiry events as
// signals so any component can react to created/updated/deleted events
// without manually subscribing/unsubscribing.
@Injectable({ providedIn: 'root' })
export class SignalrService {
  private hubConnection?: signalR.HubConnection;

  readonly created = signal<Enquiry | null>(null);
  readonly updated = signal<Enquiry | null>(null);
  readonly deletedId = signal<number | null>(null);

  constructor(private auth: AuthService) {}

  connect(): void {
    if (this.hubConnection) return; // already connected

    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl(environment.hubUrl, {
        // Token is passed as a query param because browser WebSockets
        // can't set custom headers (see matching server-side handler).
        accessTokenFactory: () => this.auth.getToken() ?? ''
      })
      .withAutomaticReconnect()
      .build();

    this.hubConnection.on('EnquiryCreated', (enquiry: Enquiry) => this.created.set(enquiry));
    this.hubConnection.on('EnquiryUpdated', (enquiry: Enquiry) => this.updated.set(enquiry));
    this.hubConnection.on('EnquiryDeleted', (id: number) => this.deletedId.set(id));

    this.hubConnection.start().catch((err) => console.error('SignalR connection failed:', err));
  }

  disconnect(): void {
    this.hubConnection?.stop();
    this.hubConnection = undefined;
  }
}
