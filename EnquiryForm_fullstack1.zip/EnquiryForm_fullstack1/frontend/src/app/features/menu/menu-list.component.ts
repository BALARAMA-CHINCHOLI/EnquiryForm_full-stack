import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MenuService } from '../../core/services/menu.service';
import { CartService } from '../../core/services/cart.service';
import { MenuItem } from '../../core/models';

@Component({
  selector: 'app-menu-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="min-h-screen bg-slate-50">
      <header class="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <h1 class="text-lg font-semibold text-slate-900">Menu</h1>
          <a routerLink="/cart" class="relative text-sm font-medium text-brand-600 hover:text-brand-700">
            Cart
            @if (cart.itemCount() > 0) {
              <span class="absolute -top-2 -right-3 bg-brand-600 text-white text-[10px] rounded-full px-1.5 py-0.5">
                {{ cart.itemCount() }}
              </span>
            }
          </a>
        </div>
      </header>

      <main class="max-w-5xl mx-auto px-4 sm:px-6 py-6">
        <!-- Responsive grid: 1 col mobile, 2 tablet, 3 desktop -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          @for (item of items(); track item.id) {
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
              <div class="h-36 bg-slate-100 flex items-center justify-center text-slate-400 text-sm">
                @if (item.imageUrl) {
                  <img [src]="item.imageUrl" [alt]="item.name" class="h-full w-full object-cover" />
                } @else {
                  No image
                }
              </div>
              <div class="p-4 flex flex-col flex-1">
                <h3 class="font-medium text-slate-900">{{ item.name }}</h3>
                <p class="text-sm text-slate-500 mt-1 flex-1">{{ item.description }}</p>
                <div class="flex items-center justify-between mt-3">
                  <span class="font-semibold text-slate-900">{{ item.price | currency }}</span>
                  <button
                    (click)="cart.add(item)"
                    class="rounded-lg bg-brand-600 text-white text-sm font-medium px-3 py-1.5 hover:bg-brand-700"
                  >
                    Add
                  </button>
                </div>
              </div>
            </div>
          }
        </div>
      </main>
    </div>
  `
})
export class MenuListComponent implements OnInit {
  items = signal<MenuItem[]>([]);

  constructor(private menuService: MenuService, public cart: CartService) {}

  ngOnInit(): void {
    this.menuService.getAll().subscribe((data) => this.items.set(data));
  }
}
