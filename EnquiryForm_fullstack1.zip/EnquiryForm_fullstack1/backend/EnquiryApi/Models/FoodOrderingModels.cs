namespace EnquiryApi.Models;

// ---------- Menu ----------

public class MenuItem
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public string Category { get; set; } = string.Empty;

    // Populated by AzureBlobStorageService when an image is uploaded for this item.
    public string? ImageUrl { get; set; }
    public bool IsAvailable { get; set; } = true;
}

// ---------- Orders ----------

public enum OrderStatus
{
    PendingPayment, // order created, awaiting successful payment
    Paid,
    Preparing,
    OutForDelivery,
    Delivered,
    Cancelled
}

public class Order
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public List<OrderItem> Items { get; set; } = new();
    public decimal TotalAmount { get; set; }
    public OrderStatus Status { get; set; } = OrderStatus.PendingPayment;
    public string DeliveryAddress { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    // Set once a Payment succeeds; one-to-one
    public int? PaymentId { get; set; }
    public Payment? Payment { get; set; }

    // Set once a Shipment is created for this order; one-to-one
    public int? ShipmentId { get; set; }
    public Shipment? Shipment { get; set; }
}

public class OrderItem
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public int MenuItemId { get; set; }
    public string MenuItemName { get; set; } = string.Empty; // snapshot at order time
    public decimal UnitPrice { get; set; }                   // snapshot at order time
    public int Quantity { get; set; }
}

// ---------- Payments ----------

public enum PaymentStatus
{
    Pending,
    Succeeded,
    Failed,
    Refunded
}

public class Payment
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public string Provider { get; set; } = "Stripe";
    public string ProviderPaymentIntentId { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "usd";
    public PaymentStatus Status { get; set; } = PaymentStatus.Pending;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

// ---------- Shipment / delivery tracking ----------

public enum ShipmentStatus
{
    Created,
    PickedUp,
    InTransit,
    OutForDelivery,
    Delivered,
    Failed
}

public class Shipment
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public string TrackingNumber { get; set; } = string.Empty;
    public string Carrier { get; set; } = "In-house Delivery";
    public ShipmentStatus Status { get; set; } = ShipmentStatus.Created;

    // Latest known coordinates -- lets the frontend show the courier on a map
    public double? CurrentLat { get; set; }
    public double? CurrentLng { get; set; }

    public List<ShipmentEvent> Events { get; set; } = new();
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

// One row per status change -- builds the "timeline" shown to the end user
public class ShipmentEvent
{
    public int Id { get; set; }
    public int ShipmentId { get; set; }
    public ShipmentStatus Status { get; set; }
    public string Note { get; set; } = string.Empty;
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}
