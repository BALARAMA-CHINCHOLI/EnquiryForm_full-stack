using EnquiryApi.Data;
using EnquiryApi.DTOs;
using EnquiryApi.Hubs;
using EnquiryApi.Models;
using EnquiryApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Stripe;

namespace EnquiryApi.Controllers;

[ApiController]
[Route("api/payments")]
public class PaymentsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly PaymentService _paymentService;
    private readonly IHubContext<OrderTrackingHub> _hub;

    public PaymentsController(AppDbContext db, PaymentService paymentService, IHubContext<OrderTrackingHub> hub)
    {
        _db = db;
        _paymentService = paymentService;
        _hub = hub;
    }

    // POST api/payments/intent -- step 1: create a Stripe PaymentIntent for an order.
    // The client takes the returned ClientSecret and confirms card details with Stripe.js.
    [HttpPost("intent")]
    [Authorize]
    public async Task<ActionResult<PaymentIntentResponseDto>> CreateIntent(CreatePaymentIntentDto dto)
    {
        var order = await _db.Orders.FindAsync(dto.OrderId);
        if (order is null) return NotFound("Order not found.");
        if (order.Status != OrderStatus.PendingPayment) return BadRequest("Order is not awaiting payment.");

        var intent = await _paymentService.CreatePaymentIntentAsync(order.TotalAmount, "usd", order.Id);

        var payment = new Payment
        {
            OrderId = order.Id,
            ProviderPaymentIntentId = intent.Id,
            Amount = order.TotalAmount,
            Status = PaymentStatus.Pending
        };
        _db.Payments.Add(payment);
        await _db.SaveChangesAsync();

        return Ok(new PaymentIntentResponseDto(intent.ClientSecret, order.TotalAmount, "usd"));
    }

    // POST api/payments/webhook -- step 2: Stripe calls this server-to-server
    // once the card payment actually succeeds/fails. We never mark an order
    // "Paid" purely from the client's say-so -- only a verified webhook does that.
    [HttpPost("webhook")]
    [AllowAnonymous]
    public async Task<IActionResult> Webhook()
    {
        var json = await new StreamReader(Request.Body).ReadToEndAsync();
        Event stripeEvent;

        try
        {
            stripeEvent = _paymentService.ParseWebhookEvent(json, Request.Headers["Stripe-Signature"]!);
        }
        catch (StripeException)
        {
            return BadRequest("Invalid Stripe signature.");
        }

        if (stripeEvent.Type == "payment_intent.succeeded" &&
            stripeEvent.Data.Object is PaymentIntent intent)
        {
            var payment = await _db.Payments
                .FirstOrDefaultAsync(p => p.ProviderPaymentIntentId == intent.Id);

            if (payment is not null)
            {
                payment.Status = PaymentStatus.Succeeded;

                var order = await _db.Orders.FindAsync(payment.OrderId);
                if (order is not null)
                {
                    order.Status = OrderStatus.Paid;
                    order.PaymentId = payment.Id;
                    order.UpdatedAt = DateTime.UtcNow;

                    // Automatically create the shipment now that payment cleared,
                    // and notify the client tracking page in real time.
                    var shipment = new Shipment
                    {
                        OrderId = order.Id,
                        TrackingNumber = $"TRK-{Guid.NewGuid().ToString()[..8].ToUpper()}",
                        Status = Models.ShipmentStatus.Created
                    };
                    shipment.Events.Add(new ShipmentEvent { Status = Models.ShipmentStatus.Created, Note = "Order confirmed, preparing for dispatch." });

                    _db.Shipments.Add(shipment);
                    await _db.SaveChangesAsync();

                    order.ShipmentId = shipment.Id;
                    await _db.SaveChangesAsync();

                    await _hub.Clients.Group(OrderTrackingHub.GroupName(order.Id))
                        .SendAsync("OrderPaid", new { orderId = order.Id, shipmentId = shipment.Id });
                }
            }
        }
        else if (stripeEvent.Type == "payment_intent.payment_failed" &&
                 stripeEvent.Data.Object is PaymentIntent failedIntent)
        {
            var payment = await _db.Payments
                .FirstOrDefaultAsync(p => p.ProviderPaymentIntentId == failedIntent.Id);
            if (payment is not null)
            {
                payment.Status = PaymentStatus.Failed;
                await _db.SaveChangesAsync();
            }
        }

        return Ok();
    }
}
