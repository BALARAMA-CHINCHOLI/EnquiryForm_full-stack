import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { inject } from '@angular/core';

import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="min-h-screen flex items-center justify-center">
      <div class="w-full max-w-md p-6 border rounded-lg shadow">
        <h2 class="text-2xl font-bold mb-4">Register</h2>

        <form [formGroup]="form" (ngSubmit)="onSubmit()">
          <div class="mb-3">
            <input
              type="text"
              formControlName="username"
              placeholder="Username"
              class="w-full border p-2 rounded"
            />
          </div>

          <div class="mb-3">
            <input
              type="email"
              formControlName="email"
              placeholder="Email"
              class="w-full border p-2 rounded"
            />
          </div>

          <div class="mb-3">
            <input
              type="password"
              formControlName="password"
              placeholder="Password"
              class="w-full border p-2 rounded"
            />
          </div>

          @if (errorMessage()) {
            <p class="text-red-600 mb-3">{{ errorMessage() }}</p>
          }

          <button
            type="submit"
            [disabled]="form.invalid || loading()"
            class="w-full bg-blue-600 text-white p-2 rounded"
          >
            {{ loading() ? 'Registering...' : 'Register' }}
          </button>
        </form>

        <p class="mt-4 text-center">
          Already have an account?
          <a routerLink="/login">Login</a>
        </p>
      </div>
    </div>
  `
})
export class RegisterComponent {
  private fb = inject(FormBuilder);

  loading = signal(false);
  errorMessage = signal<string | null>(null);

  form = this.fb.group({
    username: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]]
  });

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  onSubmit(): void {
    if (this.form.invalid) return;

    this.loading.set(true);
    this.errorMessage.set(null);

    this.auth.register(this.form.getRawValue() as any).subscribe({
      next: () => {
        this.router.navigate(['/login']);
      },
      error: (err) => {
        this.errorMessage.set(
          err?.error || 'Registration failed.'
        );
        this.loading.set(false);
      }
    });
  }
}