using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace EnquiryApi.Services;

// Thin wrapper around Azure.Storage.Blobs. Used to store menu item photos
// and generated order receipts/invoices in Azure Blob Storage instead of
// the local filesystem -- so files survive container restarts/scale-out
// and can be served directly via their public blob URL.
public class AzureBlobStorageService
{
    private readonly BlobContainerClient _menuImagesContainer;
    private readonly BlobContainerClient _receiptsContainer;

    public AzureBlobStorageService(IConfiguration config)
    {
        var connectionString = config["Azure:BlobStorage:ConnectionString"]
            ?? throw new InvalidOperationException("Azure:BlobStorage:ConnectionString is not configured.");

        var serviceClient = new BlobServiceClient(connectionString);

        _menuImagesContainer = serviceClient.GetBlobContainerClient(
            config["Azure:BlobStorage:MenuImagesContainer"] ?? "menu-images");
        _receiptsContainer = serviceClient.GetBlobContainerClient(
            config["Azure:BlobStorage:ReceiptsContainer"] ?? "receipts");

        // PublicAccessType.Blob lets images load directly via URL in <img> tags;
        // receipts stay private (Off) and should be served via short-lived SAS tokens.
        _menuImagesContainer.CreateIfNotExists(PublicAccessType.Blob);
        _receiptsContainer.CreateIfNotExists(PublicAccessType.None);
    }

    public async Task<string> UploadMenuImageAsync(Stream content, string fileName, string contentType)
    {
        var blobName = $"{Guid.NewGuid()}-{fileName}";
        var blobClient = _menuImagesContainer.GetBlobClient(blobName);

        await blobClient.UploadAsync(content, new BlobHttpHeaders { ContentType = contentType });

        return blobClient.Uri.ToString(); // public URL stored on MenuItem.ImageUrl
    }

    public async Task<string> UploadReceiptAsync(Stream content, string fileName)
    {
        var blobName = $"{Guid.NewGuid()}-{fileName}";
        var blobClient = _receiptsContainer.GetBlobClient(blobName);

        await blobClient.UploadAsync(content, new BlobHttpHeaders { ContentType = "application/pdf" });

        return blobClient.Name; // store the blob name; generate a SAS URL on demand when reading
    }

    // Generates a time-limited, signed URL so a private receipt blob can be
    // downloaded by the end user without making the whole container public.
    public Uri GetReceiptReadUrl(string blobName, TimeSpan validFor)
    {
        var blobClient = _receiptsContainer.GetBlobClient(blobName);
        return blobClient.GenerateSasUri(Azure.Storage.Sas.BlobSasPermissions.Read, DateTimeOffset.UtcNow.Add(validFor));
    }
}
