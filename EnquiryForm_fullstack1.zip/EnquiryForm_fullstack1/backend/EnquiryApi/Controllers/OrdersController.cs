using System.Security.Claims;
using EnquiryApi.Data;
using EnquiryApi.DTOs;
using EnquiryApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EnquiryApi.Controllers;

[ApiController]
[Route("api/orders")]
[Authorize]
public class OrdersController : ControllerBase
{
    private readonly AppDbContext _db;

    public OrdersController(AppDbContext db)
    {
        _db = db;
    }

    private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");

    private static OrderReadDto ToDto(Order o) => new(
        o.Id,
        o.Items.Select(i => new OrderItemReadDto(i.MenuItemId, i.MenuItemName, i.UnitPrice, i.Quantity)).ToList(),
        o.TotalAmount,
        o.Status,
        o.DeliveryAddress,
        o.CreatedAt,
        o.PaymentId,
        o.ShipmentId
    );

    // GET api/orders -- the current user's order history
    [HttpGet]
    public async Task<ActionResult<IEnumerable<OrderReadDto>>> GetMyOrders()
    {
        var orders = await _db.Orders
            .Include(o => o.Items)
            .Where(o => o.UserId == CurrentUserId)
            .OrderByDescending(o => o.CreatedAt)
            .ToListAsync();

        return Ok(orders.Select(ToDto));
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<OrderReadDto>> GetById(int id)
    {
        var order = await _db.Orders.Include(o => o.Items).FirstOrDefaultAsync(o => o.Id == id);
        if (order is null || order.UserId != CurrentUserId) return NotFound();
        return Ok(ToDto(order));
    }

    // POST api/orders -- builds an order from cart items. Prices are looked
    // up server-side from the MenuItem table (never trust a price sent by the client).
    [HttpPost]
    public async Task<ActionResult<OrderReadDto>> Create(OrderCreateDto dto)
    {
        if (dto.Items.Count == 0) return BadRequest("Cart is empty.");

        var menuItemIds = dto.Items.Select(i => i.MenuItemId).ToList();
        var menuItems = await _db.MenuItems.Where(m => menuItemIds.Contains(m.Id)).ToListAsync();

        var order = new Order
        {
            UserId = CurrentUserId,
            DeliveryAddress = dto.DeliveryAddress,
            Status = OrderStatus.PendingPayment
        };

        foreach (var requested in dto.Items)
        {
            var menuItem = menuItems.FirstOrDefault(m => m.Id == requested.MenuItemId);
            if (menuItem is null || !menuItem.IsAvailable)
                return BadRequest($"Menu item {requested.MenuItemId} is unavailable.");

            order.Items.Add(new OrderItem
            {
                MenuItemId = menuItem.Id,
                MenuItemName = menuItem.Name,
                UnitPrice = menuItem.Price,
                Quantity = requested.Quantity
            });
        }

        order.TotalAmount = order.Items.Sum(i => i.UnitPrice * i.Quantity);

        _db.Orders.Add(order);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = order.Id }, ToDto(order));
    }
}
