import { Component, OnDestroy, OnInit, effect, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EnquiryService } from '../../core/services/enquiry.service';
import { SignalrService } from '../../core/services/signalr.service';
import { AuthService } from '../../core/services/auth.service';
import { Enquiry, EnquiryStatus } from '../../core/models';
import { EnquiryFormComponent } from './enquiry-form.component';

@Component({
  selector: 'app-enquiry-list',
  standalone: true,
  imports: [CommonModule, EnquiryFormComponent],
  template: `
    <div class="min-h-screen bg-slate-50">
      <!-- Header -->
      <header class="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <h1 class="text-lg font-semibold text-slate-900">Enquiries</h1>
          <div class="flex items-center gap-3">
            <span class="text-sm text-slate-500 hidden sm:inline">{{ auth.currentUser() }}</span>
            <button (click)="auth.logout()" class="text-sm font-medium text-slate-500 hover:text-slate-800">
              Logout
            </button>
          </div>
        </div>
      </header>

      <main class="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        <!-- New enquiry form -->
        <app-enquiry-form
          [editingEnquiry]="editing()"
          (saved)="onSaved()"
          (cancelled)="editing.set(null)"
        />

        <!-- Responsive list: cards on mobile, table on larger screens -->
        <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <!-- Table header (md and up) -->
          <div class="hidden md:grid grid-cols-12 gap-2 px-5 py-3 bg-slate-50 text-xs font-medium text-slate-500 uppercase">
            <div class="col-span-3">Name</div>
            <div class="col-span-3">Subject</div>
            <div class="col-span-2">Status</div>
            <div class="col-span-2">Created</div>
            <div class="col-span-2 text-right">Actions</div>
          </div>

          @for (e of enquiries(); track e.id) {
            <div class="grid grid-cols-1 md:grid-cols-12 gap-2 px-5 py-4 border-t border-slate-100 items-center">
              <div class="md:col-span-3">
                <p class="font-medium text-slate-900">{{ e.fullName }}</p>
                <p class="text-sm text-slate-500">{{ e.email }}</p>
              </div>
              <div class="md:col-span-3 text-sm text-slate-700">{{ e.subject }}</div>
              <div class="md:col-span-2">
                <span [class]="statusBadgeClass(e.status)">{{ statusLabel(e.status) }}</span>
              </div>
              <div class="md:col-span-2 text-sm text-slate-500">
                {{ e.createdAt | date: 'MMM d, y, h:mm a' }}
              </div>
              <div class="md:col-span-2 flex gap-3 md:justify-end">
                <button (click)="editing.set(e)" class="text-sm font-medium text-brand-600 hover:text-brand-700">
                  Edit
                </button>
                <button (click)="onDelete(e.id)" class="text-sm font-medium text-red-600 hover:text-red-700">
                  Delete
                </button>
              </div>
            </div>
          } @empty {
            <p class="px-5 py-8 text-center text-sm text-slate-500">No enquiries yet.</p>
          }
        </div>
      </main>
    </div>
  `
})
export class EnquiryListComponent implements OnInit, OnDestroy {
  enquiries = signal<Enquiry[]>([]);
  editing = signal<Enquiry | null>(null);

  constructor(
    private enquiryService: EnquiryService,
    private signalr: SignalrService,
    public auth: AuthService
  ) {
    // These effects react to live SignalR pushes (see signalr.service.ts)
    // and patch the local list in place -- no manual refetch needed.
    effect(() => {
      const created = this.signalr.created();
      if (created) this.enquiries.update((list) => [created, ...list]);
    });

    effect(() => {
      const updated = this.signalr.updated();
      if (updated) {
        this.enquiries.update((list) =>
          list.map((e) => (e.id === updated.id ? updated : e))
        );
      }
    });

    effect(() => {
      const deletedId = this.signalr.deletedId();
      if (deletedId !== null) {
        this.enquiries.update((list) => list.filter((e) => e.id !== deletedId));
      }
    });
  }

  ngOnInit(): void {
    this.signalr.connect();
    this.refresh();
  }

  ngOnDestroy(): void {
    this.signalr.disconnect();
  }

  refresh(): void {
    this.enquiryService.getAll().subscribe((data) => this.enquiries.set(data));
  }

  onSaved(): void {
    this.editing.set(null);
    // No manual refresh needed for create -- SignalR pushes it in.
    // We still refresh on update so any other field changes reflect immediately.
  }

  onDelete(id: number): void {
    if (!confirm('Delete this enquiry?')) return;
    this.enquiryService.delete(id).subscribe();
  }

  statusLabel(status: EnquiryStatus): string {
    return { 0: 'New', 1: 'In Progress', 2: 'Resolved' }[status] ?? 'Unknown';
  }

  statusBadgeClass(status: EnquiryStatus): string {
    const base = 'inline-block rounded-full px-2.5 py-0.5 text-xs font-medium';
    return {
      [EnquiryStatus.New]: `${base} bg-amber-100 text-amber-700`,
      [EnquiryStatus.InProgress]: `${base} bg-blue-100 text-blue-700`,
      [EnquiryStatus.Resolved]: `${base} bg-emerald-100 text-emerald-700`
    }[status];
  }
}
