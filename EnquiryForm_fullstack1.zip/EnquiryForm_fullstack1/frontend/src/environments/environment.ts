/*
export const environment = {
  production: false,
  apiUrl: 'https://localhost:5001/api',
  hubUrl: 'https://localhost:5001/hubs/enquiries',
  orderTrackingHubUrl: 'https://localhost:5001/hubs/order-tracking',
  // Publishable keys are safe to expose client-side (unlike secret keys)
  stripePublishableKey: 'pk_test_REPLACE_WITH_YOUR_STRIPE_PUBLISHABLE_KEY'
};
*/

export const environment = {
  production: false,
  apiUrl: 'http://localhost:5000/api',
  hubUrl: 'http://localhost:5000/hubs/enquiries',
  orderTrackingHubUrl: 'http://localhost:5000/hubs/order-tracking',
    // Publishable keys are safe to expose client-side (unlike secret keys)
  stripePublishableKey: 'pk_test_REPLACE_WITH_YOUR_STRIPE_PUBLISHABLE_KEY'
};