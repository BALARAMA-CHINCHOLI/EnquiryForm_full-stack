using EnquiryApi.Data;
using EnquiryApi.DTOs;
using EnquiryApi.Hubs;
using EnquiryApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;

namespace EnquiryApi.Controllers;

[ApiController]
[Route("api/shipments")]
[Authorize]
public class ShipmentsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IHubContext<OrderTrackingHub> _hub;

    public ShipmentsController(AppDbContext db, IHubContext<OrderTrackingHub> hub)
    {
        _db = db;
        _hub = hub;
    }

    private static ShipmentReadDto ToDto(Shipment s) => new(
        s.Id, s.OrderId, s.TrackingNumber, s.Carrier, s.Status, s.CurrentLat, s.CurrentLng,
        s.Events.OrderBy(e => e.Timestamp)
            .Select(e => new ShipmentEventDto(e.Status, e.Note, e.Timestamp)).ToList()
    );

    // GET api/shipments/by-order/5 -- what the end user's tracking page polls/loads initially
    [HttpGet("by-order/{orderId:int}")]
    public async Task<ActionResult<ShipmentReadDto>> GetByOrder(int orderId)
    {
        var shipment = await _db.Shipments
            .Include(s => s.Events)
            .FirstOrDefaultAsync(s => s.OrderId == orderId);

        return shipment is null ? NotFound() : Ok(ToDto(shipment));
    }

    // PUT api/shipments/5/status -- called by courier app / admin dashboard /
    // delivery-partner webhook as the package physically moves. Each call
    // appends a timeline event and pushes a live update to the customer's
    // open tracking page via SignalR -- no refresh needed.
    [HttpPut("{id:int}/status")]
    public async Task<ActionResult<ShipmentReadDto>> UpdateStatus(int id, ShipmentStatusUpdateDto dto)
    {
        var shipment = await _db.Shipments.Include(s => s.Events).FirstOrDefaultAsync(s => s.Id == id);
        if (shipment is null) return NotFound();

        shipment.Status = dto.Status;
        if (dto.Lat.HasValue) shipment.CurrentLat = dto.Lat;
        if (dto.Lng.HasValue) shipment.CurrentLng = dto.Lng;
        shipment.Events.Add(new ShipmentEvent { Status = dto.Status, Note = dto.Note });

        // Keep the parent order's status in sync with delivery progress
        var order = await _db.Orders.FindAsync(shipment.OrderId);
        if (order is not null)
        {
            order.Status = dto.Status switch
            {
                ShipmentStatus.OutForDelivery => OrderStatus.OutForDelivery,
                ShipmentStatus.Delivered => OrderStatus.Delivered,
                _ => order.Status
            };
        }

        await _db.SaveChangesAsync();

        var result = ToDto(shipment);
        await _hub.Clients.Group(OrderTrackingHub.GroupName(shipment.OrderId))
            .SendAsync("ShipmentStatusUpdated", result);

        return Ok(result);
    }
}
