// Mirrors the C# DTOs on the backend so the frontend stays in sync with the API contract.

export interface AuthResponse {
  token: string;
  username: string;
  role: string;
  expiresAt: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
}

export enum EnquiryStatus {
  New = 0,
  InProgress = 1,
  Resolved = 2
}

export interface Enquiry {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  status: EnquiryStatus;
  createdAt: string;
  updatedAt?: string;
}

// Used for both create and update forms; id/status are added where relevant.
export interface EnquiryFormValue {
  fullName: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
}

// ---------- Menu / Food ordering ----------

export interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  imageUrl?: string;
  isAvailable: boolean;
}

// Client-side cart line -- not sent to the API directly, used to build OrderCreateRequest
export interface CartLine {
  menuItem: MenuItem;
  quantity: number;
}

export interface OrderItemRequest {
  menuItemId: number;
  quantity: number;
}

export interface OrderCreateRequest {
  items: OrderItemRequest[];
  deliveryAddress: string;
}

export enum OrderStatus {
  PendingPayment = 0,
  Paid = 1,
  Preparing = 2,
  OutForDelivery = 3,
  Delivered = 4,
  Cancelled = 5
}

export interface OrderItem {
  menuItemId: number;
  menuItemName: string;
  unitPrice: number;
  quantity: number;
}

export interface Order {
  id: number;
  items: OrderItem[];
  totalAmount: number;
  status: OrderStatus;
  deliveryAddress: string;
  createdAt: string;
  paymentId?: number;
  shipmentId?: number;
}

// ---------- Payments ----------

export interface PaymentIntentResponse {
  clientSecret: string;
  amount: number;
  currency: string;
}

// ---------- Shipment tracking ----------

export enum ShipmentStatus {
  Created = 0,
  PickedUp = 1,
  InTransit = 2,
  OutForDelivery = 3,
  Delivered = 4,
  Failed = 5
}

export interface ShipmentEvent {
  status: ShipmentStatus;
  note: string;
  timestamp: string;
}

export interface Shipment {
  id: number;
  orderId: number;
  trackingNumber: string;
  carrier: string;
  status: ShipmentStatus;
  currentLat?: number;
  currentLng?: number;
  events: ShipmentEvent[];
}
