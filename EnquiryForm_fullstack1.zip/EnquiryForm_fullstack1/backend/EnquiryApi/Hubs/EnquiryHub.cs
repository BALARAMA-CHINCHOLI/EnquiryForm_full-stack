using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace EnquiryApi.Hubs;

// EnquiryHub is the real-time channel. Whenever an enquiry is created,
// updated, or deleted, EnquiriesController broadcasts an event here, and
// every connected Angular client updates its UI instantly -- no polling.
// [Authorize] means only clients with a valid JWT can open the WebSocket.
[Authorize]
public class EnquiryHub : Hub
{
    public override async Task OnConnectedAsync()
    {
        // Group everyone into a single "enquiries" room. For multi-tenant
        // apps you'd instead group by company/department id.
        await Groups.AddToGroupAsync(Context.ConnectionId, "enquiries");
        await base.OnConnectedAsync();
    }
}
