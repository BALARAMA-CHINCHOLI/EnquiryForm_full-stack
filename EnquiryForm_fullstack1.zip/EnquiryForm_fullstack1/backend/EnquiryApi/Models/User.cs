namespace EnquiryApi.Models;

// Represents an application user stored in the database.
// Passwords are NEVER stored in plain text -- only the BCrypt hash is saved.
public class User
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string Role { get; set; } = "User"; // simple role-based access (User / Admin)
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
