using EnquiryApi.Data;
using EnquiryApi.DTOs;
using EnquiryApi.Hubs;
using EnquiryApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace EnquiryApi.Controllers;

// Full CRUD for the Enquiry entity. Every mutating action (Create/Update/Delete)
// also pushes a SignalR event so all connected Angular clients refresh live.
[ApiController]
[Route("api/enquiries")]
[Authorize] // requires a valid JWT bearer token for every endpoint in this controller
public class EnquiriesController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IHubContext<EnquiryHub> _hub;

    public EnquiriesController(AppDbContext db, IHubContext<EnquiryHub> hub)
    {
        _db = db;
        _hub = hub;
    }

    private static EnquiryReadDto ToDto(Enquiry e) => new(
        e.Id, e.FullName, e.Email, e.Phone, e.Subject, e.Message, e.Status, e.CreatedAt, e.UpdatedAt);

    // GET api/enquiries
    [HttpGet]
    public async Task<ActionResult<IEnumerable<EnquiryReadDto>>> GetAll()
    {
        var enquiries = await _db.Enquiries
            .OrderByDescending(e => e.CreatedAt)
            .ToListAsync();

        return Ok(enquiries.Select(ToDto));
    }

    // GET api/enquiries/5
    [HttpGet("{id:int}")]
    public async Task<ActionResult<EnquiryReadDto>> GetById(int id)
    {
        var enquiry = await _db.Enquiries.FindAsync(id);
        return enquiry is null ? NotFound() : Ok(ToDto(enquiry));
    }

    // POST api/enquiries
    [HttpPost]
    public async Task<ActionResult<EnquiryReadDto>> Create(EnquiryCreateDto dto)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");

        var enquiry = new Enquiry
        {
            FullName = dto.FullName,
            Email = dto.Email,
            Phone = dto.Phone,
            Subject = dto.Subject,
            Message = dto.Message,
            CreatedByUserId = userId
        };

        _db.Enquiries.Add(enquiry);
        await _db.SaveChangesAsync();

        var result = ToDto(enquiry);

        // Broadcast to every connected client so lists update without a refresh
        await _hub.Clients.Group("enquiries").SendAsync("EnquiryCreated", result);

        return CreatedAtAction(nameof(GetById), new { id = enquiry.Id }, result);
    }

    // PUT api/enquiries/5
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, EnquiryUpdateDto dto)
    {
        var enquiry = await _db.Enquiries.FindAsync(id);
        if (enquiry is null) return NotFound();

        enquiry.FullName = dto.FullName;
        enquiry.Email = dto.Email;
        enquiry.Phone = dto.Phone;
        enquiry.Subject = dto.Subject;
        enquiry.Message = dto.Message;
        enquiry.Status = dto.Status;
        enquiry.UpdatedAt = DateTime.UtcNow;

        await _db.SaveChangesAsync();

        var result = ToDto(enquiry);
        await _hub.Clients.Group("enquiries").SendAsync("EnquiryUpdated", result);

        return Ok(result);
    }

    // DELETE api/enquiries/5
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var enquiry = await _db.Enquiries.FindAsync(id);
        if (enquiry is null) return NotFound();

        _db.Enquiries.Remove(enquiry);
        await _db.SaveChangesAsync();

        await _hub.Clients.Group("enquiries").SendAsync("EnquiryDeleted", id);

        return NoContent();
    }
}
