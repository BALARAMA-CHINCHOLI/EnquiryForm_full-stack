import { Component, OnDestroy, OnInit, effect, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { OrderTrackingService } from '../../core/services/order-tracking.service';
import { Shipment, ShipmentStatus } from '../../core/models';

// Shows the live delivery timeline for one order. On load it fetches the
// current shipment state, then joins the order's SignalR group so any
// later courier status update (e.g. "Out for delivery") appears instantly --
// this is the "shipping track up to the end user" piece end-to-end.
@Component({
  selector: 'app-order-tracking',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="min-h-screen bg-slate-50 flex items-center justify-center px-4 py-10">
      <div class="w-full max-w-md bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <h1 class="text-lg font-semibold text-slate-900 mb-1">Track your order</h1>

        @if (shipment()) {
          <p class="text-sm text-slate-500 mb-5">
            Tracking number <span class="font-medium text-slate-700">{{ shipment()!.trackingNumber }}</span>
            · {{ shipment()!.carrier }}
          </p>

          <ol class="space-y-4">
            @for (event of shipment()!.events; track event.timestamp) {
              <li class="flex gap-3">
                <span class="mt-1 w-2.5 h-2.5 rounded-full bg-brand-500 shrink-0"></span>
                <div>
                  <p class="text-sm font-medium text-slate-900">{{ statusLabel(event.status) }}</p>
                  <p class="text-xs text-slate-500">{{ event.note }}</p>
                  <p class="text-xs text-slate-400">{{ event.timestamp | date: 'MMM d, h:mm a' }}</p>
                </div>
              </li>
            }
          </ol>
        } @else {
          <p class="text-sm text-slate-500">Waiting for shipment details... this updates automatically once payment is confirmed.</p>
        }
      </div>
    </div>
  `
})
export class OrderTrackingComponent implements OnInit, OnDestroy {
  orderId!: number;
  shipment = signal<Shipment | null>(null);

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private tracking: OrderTrackingService
  ) {
    // Fires whenever a live ShipmentStatusUpdated event arrives for this order
    effect(() => {
      const update = this.tracking.shipmentUpdate();
      if (update && update.orderId === this.orderId) {
        this.shipment.set(update);
      }
    });
  }

  async ngOnInit(): Promise<void> {
    this.orderId = Number(this.route.snapshot.paramMap.get('orderId'));

    // Initial snapshot via REST; live updates afterwards via SignalR
    this.http
      .get<Shipment>(`${environment.apiUrl}/shipments/by-order/${this.orderId}`)
      .subscribe({
        next: (s) => this.shipment.set(s),
        error: () => {} // shipment may not exist yet if payment hasn't completed
      });

    await this.tracking.connectAndTrack(this.orderId);
  }

  async ngOnDestroy(): Promise<void> {
    await this.tracking.stopTracking(this.orderId);
  }

  statusLabel(status: ShipmentStatus): string {
    return {
      [ShipmentStatus.Created]: 'Order confirmed',
      [ShipmentStatus.PickedUp]: 'Picked up by courier',
      [ShipmentStatus.InTransit]: 'In transit',
      [ShipmentStatus.OutForDelivery]: 'Out for delivery',
      [ShipmentStatus.Delivered]: 'Delivered',
      [ShipmentStatus.Failed]: 'Delivery failed'
    }[status];
  }
}
