using Stripe;

namespace EnquiryApi.Services;

// Wraps Stripe.net. Stripe is used here as the payment gateway; the same
// pattern (create PaymentIntent server-side, confirm card details client-side
// with Stripe.js, then verify via webhook) applies to other gateways too.
public class PaymentService
{
    private readonly string _webhookSecret;

    public PaymentService(IConfiguration config)
    {
        StripeConfiguration.ApiKey = config["Stripe:SecretKey"];
        _webhookSecret = config["Stripe:WebhookSecret"] ?? string.Empty;
    }

    // Creates a PaymentIntent for the order total. The returned ClientSecret
    // is sent to the Angular client, which uses Stripe.js to collect card
    // details and confirm the payment WITHOUT the card number ever touching our API.
    public async Task<PaymentIntent> CreatePaymentIntentAsync(decimal amount, string currency, int orderId)
    {
        var service = new PaymentIntentService();
        return await service.CreateAsync(new PaymentIntentCreateOptions
        {
            // Stripe expects the smallest currency unit (cents)
            Amount = (long)(amount * 100),
            Currency = currency,
            Metadata = new Dictionary<string, string> { { "orderId", orderId.ToString() } },
            AutomaticPaymentMethods = new PaymentIntentAutomaticPaymentMethodsOptions { Enabled = true }
        });
    }

    // Validates that a webhook request genuinely came from Stripe using the
    // signing secret, then parses it into a typed Event. Always verify
    // signatures -- never trust webhook payloads blindly.
    public Event ParseWebhookEvent(string json, string stripeSignatureHeader)
    {
        return EventUtility.ConstructEvent(json, stripeSignatureHeader, _webhookSecret);
    }
}
