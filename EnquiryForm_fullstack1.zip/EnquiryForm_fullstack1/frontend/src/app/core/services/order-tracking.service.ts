import { Injectable, signal } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { environment } from '../../../environments/environment';
import { AuthService } from './auth.service';
import { Shipment } from '../models';

// Live shipment tracking. The connection joins a per-order group on the
// server (OrderTrackingHub.JoinOrderTrackingGroup) so the end user's
// tracking page gets pushed every status/location change for THEIR order,
// e.g. "Out for delivery" appearing the instant a courier updates it.
@Injectable({ providedIn: 'root' })
export class OrderTrackingService {
  private connection?: signalR.HubConnection;

  readonly shipmentUpdate = signal<Shipment | null>(null);
  readonly orderPaid = signal<{ orderId: number; shipmentId: number } | null>(null);

  constructor(private auth: AuthService) {}

  async connectAndTrack(orderId: number): Promise<void> {
    if (!this.connection) {
      this.connection = new signalR.HubConnectionBuilder()
        .withUrl(environment.orderTrackingHubUrl, {
          accessTokenFactory: () => this.auth.getToken() ?? ''
        })
        .withAutomaticReconnect()
        .build();

      this.connection.on('ShipmentStatusUpdated', (shipment: Shipment) => this.shipmentUpdate.set(shipment));
      this.connection.on('OrderPaid', (payload: { orderId: number; shipmentId: number }) =>
        this.orderPaid.set(payload)
      );

      await this.connection.start();
    }

    await this.connection.invoke('JoinOrderTrackingGroup', orderId);
  }

  async stopTracking(orderId: number): Promise<void> {
    await this.connection?.invoke('LeaveOrderTrackingGroup', orderId);
  }

  disconnect(): void {
    this.connection?.stop();
    this.connection = undefined;
  }
}
