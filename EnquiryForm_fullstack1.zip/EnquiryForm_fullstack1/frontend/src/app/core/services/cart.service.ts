import { Injectable, computed, signal } from '@angular/core';
import { CartLine, MenuItem } from '../models';

// Pure client-side cart state. Kept in a signal so the navbar badge,
// cart page, and checkout total all stay in sync automatically.
// Prices are only ever for display here -- the API recalculates and
// trusts only its own MenuItem prices when the order is actually placed.
@Injectable({ providedIn: 'root' })
export class CartService {
  private readonly _lines = signal<CartLine[]>([]);

  readonly lines = computed(() => this._lines());
  readonly itemCount = computed(() => this._lines().reduce((sum, l) => sum + l.quantity, 0));
  readonly total = computed(() =>
    this._lines().reduce((sum, l) => sum + l.menuItem.price * l.quantity, 0)
  );

  add(menuItem: MenuItem): void {
    this._lines.update((lines) => {
      const existing = lines.find((l) => l.menuItem.id === menuItem.id);
      if (existing) {
        return lines.map((l) =>
          l.menuItem.id === menuItem.id ? { ...l, quantity: l.quantity + 1 } : l
        );
      }
      return [...lines, { menuItem, quantity: 1 }];
    });
  }

  updateQuantity(menuItemId: number, quantity: number): void {
    if (quantity <= 0) {
      this.remove(menuItemId);
      return;
    }
    this._lines.update((lines) =>
      lines.map((l) => (l.menuItem.id === menuItemId ? { ...l, quantity } : l))
    );
  }

  remove(menuItemId: number): void {
    this._lines.update((lines) => lines.filter((l) => l.menuItem.id !== menuItemId));
  }

  clear(): void {
    this._lines.set([]);
  }
}
