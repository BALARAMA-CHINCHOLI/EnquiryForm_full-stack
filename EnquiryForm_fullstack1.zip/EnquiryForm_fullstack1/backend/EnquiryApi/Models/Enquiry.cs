namespace EnquiryApi.Models;

// Core domain entity for the "Enquiry" app (e.g. customer/support enquiries).
public class Enquiry
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;

    // Status drives the Kanban-style UI on the frontend: New -> InProgress -> Resolved
    public EnquiryStatus Status { get; set; } = EnquiryStatus.New;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    // Tracks which user created/owns the enquiry record
    public int CreatedByUserId { get; set; }
}

public enum EnquiryStatus
{
    New,
    InProgress,
    Resolved
}
