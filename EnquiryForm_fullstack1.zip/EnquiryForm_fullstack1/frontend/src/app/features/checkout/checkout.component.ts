import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { StripeElements } from '@stripe/stripe-js';
import { PaymentService } from '../../core/services/payment.service';

// Step 2 of the payment flow (step 1 -- creating the order -- already
// happened in CartComponent). Here we:
//  1. Ask the API for a PaymentIntent client secret for this order
//  2. Mount Stripe's hosted PaymentElement (collects card details securely)
//  3. Confirm the payment; Stripe's webhook (server-side) then marks the
//     order Paid and creates the Shipment -- the redirect below just takes
//     the user to the tracking page, which will show the update live.
@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="min-h-screen bg-slate-50 flex items-center justify-center px-4">
      <div class="w-full max-w-md bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <h1 class="text-lg font-semibold text-slate-900 mb-1">Payment</h1>
        <p class="text-sm text-slate-500 mb-4">Order #{{ orderId }} — {{ amount() | currency }}</p>

        <!-- Stripe mounts its secure card form into this div -->
        <div id="payment-element" class="mb-4"></div>

        @if (errorMessage()) {
          <p class="text-sm text-red-600 mb-3">{{ errorMessage() }}</p>
        }

        <button
          (click)="pay()"
          [disabled]="paying() || !elementsReady()"
          class="w-full rounded-lg bg-brand-600 text-white text-sm font-medium py-2.5
                 hover:bg-brand-700 transition disabled:opacity-50"
        >
          {{ paying() ? 'Processing...' : 'Pay now' }}
        </button>
      </div>
    </div>
  `
})
export class CheckoutComponent implements OnInit {
  orderId!: number;
  amount = signal(0);
  paying = signal(false);
  elementsReady = signal(false);
  errorMessage = signal<string | null>(null);

  private elements?: StripeElements;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private paymentService: PaymentService
  ) {}

  async ngOnInit(): Promise<void> {
    this.orderId = Number(this.route.snapshot.paramMap.get('orderId'));

    const intent = await this.paymentService.createIntent(this.orderId);
    this.amount.set(intent.amount);

    this.elements = await this.paymentService.createElements(intent.clientSecret, 'payment-element');
    this.elementsReady.set(true);
  }

  async pay(): Promise<void> {
    if (!this.elements) return;
    this.paying.set(true);
    this.errorMessage.set(null);

    const { error } = await this.paymentService.confirmPayment(
      this.elements,
      `${window.location.origin}/orders/${this.orderId}/track`
    );

    if (error) {
      this.errorMessage.set(error.message ?? 'Payment failed.');
      this.paying.set(false);
      return;
    }

    // Webhook on the server confirms payment and creates the shipment;
    // the tracking page picks that up live via SignalR.
    this.router.navigate(['/orders', this.orderId, 'track']);
  }
}
