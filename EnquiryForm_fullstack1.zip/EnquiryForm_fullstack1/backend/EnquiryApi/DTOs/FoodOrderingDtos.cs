using EnquiryApi.Models;

namespace EnquiryApi.DTOs;

// ---------- Menu ----------

public record MenuItemDto(int Id, string Name, string Description, decimal Price, string Category, string? ImageUrl, bool IsAvailable);

public record MenuItemCreateDto(string Name, string Description, decimal Price, string Category);

// ---------- Orders ----------

public record OrderItemRequestDto(int MenuItemId, int Quantity);

public record OrderCreateDto(List<OrderItemRequestDto> Items, string DeliveryAddress);

public record OrderItemReadDto(int MenuItemId, string MenuItemName, decimal UnitPrice, int Quantity);

public record OrderReadDto(
    int Id,
    List<OrderItemReadDto> Items,
    decimal TotalAmount,
    OrderStatus Status,
    string DeliveryAddress,
    DateTime CreatedAt,
    int? PaymentId,
    int? ShipmentId
);

// ---------- Payments ----------

// Client calls this first to get a Stripe PaymentIntent client secret,
// then confirms the card payment in the browser using Stripe.js.
public record CreatePaymentIntentDto(int OrderId);

public record PaymentIntentResponseDto(string ClientSecret, decimal Amount, string Currency);

// ---------- Shipments ----------

public record ShipmentEventDto(ShipmentStatus Status, string Note, DateTime Timestamp);

public record ShipmentReadDto(
    int Id,
    int OrderId,
    string TrackingNumber,
    string Carrier,
    ShipmentStatus Status,
    double? CurrentLat,
    double? CurrentLng,
    List<ShipmentEventDto> Events
);

public record ShipmentStatusUpdateDto(ShipmentStatus Status, string Note, double? Lat, double? Lng);
