import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { RegisterComponent } from './features/auth/register.cmponent';

// Standalone routing: each route points directly at a component class,
// no NgModules required (Angular 21/22 default app structure).
export const routes: Routes = [
  { path: '', redirectTo: 'menu', pathMatch: 'full' },
  {
    path: 'register',
    loadComponent: () => import('./features/auth/register.cmponent').then((m) => m.RegisterComponent)
  },
  {
    path: 'login',
    loadComponent: () => import('./features/auth/login.component').then((m) => m.LoginComponent)
  },
  {
    path: 'enquiries',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/enquiries/enquiry-list.component').then((m) => m.EnquiryListComponent)
  },
  {
    path: 'menu',
    canActivate: [authGuard],
    loadComponent: () => import('./features/menu/menu-list.component').then((m) => m.MenuListComponent)
  },
  {
    path: 'cart',
    canActivate: [authGuard],
    loadComponent: () => import('./features/cart/cart.component').then((m) => m.CartComponent)
  },
  {
    path: 'checkout/:orderId',
    canActivate: [authGuard],
    loadComponent: () => import('./features/checkout/checkout.component').then((m) => m.CheckoutComponent)
  },
  {
    path: 'orders/:orderId/track',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/orders/order-tracking.component').then((m) => m.OrderTrackingComponent)
  },
  { path: '**', redirectTo: 'menu' }
];
