import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="min-h-screen flex items-center justify-center bg-slate-50 px-4">
      <div class="w-full max-w-sm bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
        <h1 class="text-2xl font-semibold text-slate-900 mb-1">Welcome back</h1>
        <p class="text-sm text-slate-500 mb-6">Sign in to manage enquiries</p>

        <form [formGroup]="form" (ngSubmit)="onSubmit()" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Username</label>
            <input
              type="text"
              formControlName="username"
              class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm
                     focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Password</label>
            <input
              type="password"
              formControlName="password"
              class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm
                     focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500"
            />
          </div>

          @if (errorMessage()) {
            <p class="text-sm text-red-600">{{ errorMessage() }}</p>
          }

          <button
            type="submit"
            [disabled]="form.invalid || loading()"
            class="w-full rounded-lg bg-brand-600 text-white text-sm font-medium py-2.5
                   hover:bg-brand-700 transition disabled:opacity-50"
          >
            {{ loading() ? 'Signing in...' : 'Sign in' }}
          </button>
        </form>

        <p class="text-sm text-slate-500 mt-6 text-center">
          No account? <a routerLink="/register" class="text-brand-600 font-medium">Register</a>
        </p>
      </div>
    </div>
  `
})
export class LoginComponent {
  loading = signal(false);
  errorMessage = signal<string | null>(null);

  //Property 'fb' is used before its initialization.
  //private fb = inject(FormBuilder);
  
  form: any;

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {
    this.form = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.form.invalid) return;

    this.loading.set(true);
    this.errorMessage.set(null);

    this.auth.login(this.form.getRawValue() as any).subscribe({
      next: () => this.router.navigate(['/enquiries']),
      error: () => {
        this.errorMessage.set('Invalid username or password.');
        this.loading.set(false);
      }
    });
  }
}
