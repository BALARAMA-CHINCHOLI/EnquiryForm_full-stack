import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Enquiry, EnquiryFormValue, EnquiryStatus } from '../models';

@Injectable({ providedIn: 'root' })
export class EnquiryService {
  private readonly baseUrl = `${environment.apiUrl}/enquiries`;

  constructor(private http: HttpClient) {}

  getAll(): Observable<Enquiry[]> {
    return this.http.get<Enquiry[]>(this.baseUrl);
  }

  getById(id: number): Observable<Enquiry> {
    return this.http.get<Enquiry>(`${this.baseUrl}/${id}`);
  }

  create(payload: EnquiryFormValue): Observable<Enquiry> {
    return this.http.post<Enquiry>(this.baseUrl, payload);
  }

  update(id: number, payload: EnquiryFormValue & { status: EnquiryStatus }): Observable<Enquiry> {
    return this.http.put<Enquiry>(`${this.baseUrl}/${id}`, payload);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
