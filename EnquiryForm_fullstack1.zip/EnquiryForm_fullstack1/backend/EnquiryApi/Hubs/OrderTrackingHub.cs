using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace EnquiryApi.Hubs;

// Separate hub from EnquiryHub so order-tracking traffic (frequent courier
// location/status pings) doesn't mix with the enquiry CRM channel.
// Each user joins a group scoped to their own order so they only receive
// updates relevant to them (rather than every order in the system).
[Authorize]
public class OrderTrackingHub : Hub
{
    public async Task JoinOrderTrackingGroup(int orderId)
    {
        await Groups.AddToGroupAsync(Context.ConnectionId, GroupName(orderId));
    }

    public async Task LeaveOrderTrackingGroup(int orderId)
    {
        await Groups.RemoveFromGroupAsync(Context.ConnectionId, GroupName(orderId));
    }

    public static string GroupName(int orderId) => $"order-{orderId}";
}
