using EnquiryApi.Data;
using EnquiryApi.DTOs;
using EnquiryApi.Models;
using EnquiryApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EnquiryApi.Controllers;

[ApiController]
[Route("api/menu")]
public class MenuController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly AzureBlobStorageService _blobStorage;

    public MenuController(AppDbContext db, AzureBlobStorageService blobStorage)
    {
        _db = db;
        _blobStorage = blobStorage;
    }

    private static MenuItemDto ToDto(MenuItem m) =>
        new(m.Id, m.Name, m.Description, m.Price, m.Category, m.ImageUrl, m.IsAvailable);

    // GET api/menu -- public browsing, no auth required
    [HttpGet]
    [AllowAnonymous]
    public async Task<ActionResult<IEnumerable<MenuItemDto>>> GetAll()
    {
        var items = await _db.MenuItems.Where(m => m.IsAvailable).ToListAsync();
        return Ok(items.Select(ToDto));
    }

    // POST api/menu -- create a menu item (would be [Authorize(Roles="Admin")] in production)
    [HttpPost]
    [Authorize]
    public async Task<ActionResult<MenuItemDto>> Create(MenuItemCreateDto dto)
    {
        var item = new MenuItem
        {
            Name = dto.Name,
            Description = dto.Description,
            Price = dto.Price,
            Category = dto.Category
        };

        _db.MenuItems.Add(item);
        await _db.SaveChangesAsync();
        return Ok(ToDto(item));
    }

    // POST api/menu/5/image -- multipart upload, stored in Azure Blob Storage
    [HttpPost("{id:int}/image")]
    [Authorize]
    [RequestSizeLimit(5_000_000)] // 5MB cap on uploaded images
    public async Task<ActionResult<MenuItemDto>> UploadImage(int id, IFormFile file)
    {
        var item = await _db.MenuItems.FindAsync(id);
        if (item is null) return NotFound();

        if (file.Length == 0) return BadRequest("Empty file.");

        using var stream = file.OpenReadStream();
        var url = await _blobStorage.UploadMenuImageAsync(stream, file.FileName, file.ContentType);

        item.ImageUrl = url;
        await _db.SaveChangesAsync();

        return Ok(ToDto(item));
    }
}
